import React from 'react'
import DisplayCartItem from '../components/DisplayCartItem'

const CartMobile = () => {
  return (
    <DisplayCartItem/>
  )
}

export default CartMobile